import numpy as np
import tensorflow as tf

import os
import urllib


class FeedForwardNet:
    """
    Simple feed forward neural network class
    """

    def __init__(self, logdir, hidden_sizes, l2_reg=0.0, dropout=0.0, use_batch_norm=False, seed=42):
        """ FeedForwardNet constructor.

        Parameters
        ----------
        hidden_sizes: list of ints
            The sizes of the hidden layers of the network.
        layer_types: list of strings
            The types of hidden layers' nonlinearities
        l2_reg: float
            The strength of L2 regularization (0 means no regularization)
        dropout: float
            The strength of dropout, (0 means no dropout)
        use_batch_norm: bool
            Whether to use batch norm or not
        seed: int
            Seed for graph initialization so that the results are reproducible
        """

        self.hidden_sizes = hidden_sizes
        self.dropout = dropout
        self.l2_reg = l2_reg

        graph = tf.Graph()
        graph.seed = seed
        self.session = tf.Session(graph=graph)
        self.logdir = logdir
        self.use_batch_norm = use_batch_norm
        self.use_reg = self.l2_reg > 0
        self.use_dropout = self.dropout > 0


    def build(self, data_dim, num_classes):
        """ FeedForwardNet build method.
        It creates the tf graph and initializes variables

        Parameters
        ----------
        data_dim: int
            Number of input data parameters
        num_classes: int
            Number of classification classes
        """

        with self.session.graph.as_default():
            self.X = tf.placeholder(
                shape=[None, data_dim], dtype=tf.float32, name="data")  # [NxD]
            self.Y = tf.placeholder(
                shape=[None, num_classes], dtype=tf.float32, name="labels")  # [Nx1]

            # Create placeholder variable for dropout training flag
            self.is_training = tf.placeholder(tf.bool, [], name="is_training")

            # l is the current last "layer" when constructing the network
            l = self.X
            for ix, hidden_size in enumerate(self.hidden_sizes):
                # Apply droupout
                if(self.use_dropout):
                    l = tf.layers.dropout(
                        inputs=l,
                        rate=self.dropout,
                        training=self.is_training)

                # Add fully connected layer with regularization
                regularizer = None
                if self.use_reg:
                    regularizer = tf.contrib.layers.l2_regularizer(
                        scale=self.l2_reg)

                # Dense without relu to bcs we want to be able to add batchnorm in between
                l = tf.layers.dense(
                    inputs=l,
                    units=hidden_size,
                    activation=None,
                    kernel_regularizer=regularizer,
                    name="hidden_layer" + str(ix))

                # Add batchnorm
                if self.use_batch_norm:
                    l = tf.layers.batch_normalization(
                        l, training=self.is_training)

                # Non linearity
                l = tf.nn.relu(l)

            # Last output layer without non-linearity
            regularizer = None
            if self.use_reg:
                regularizer = tf.contrib.layers.l2_regularizer(
                    scale=self.l2_reg)

            out = tf.layers.dense(
                inputs=l,
                units=num_classes,
                activation=None,
                kernel_regularizer=regularizer,
                name="output_layer")

            self.logits = out

            self.l2_norm = 0

            if self.use_reg:
                self.l2_norm = tf.losses.get_regularization_loss()

            self.cross_entropy_loss = tf.losses.softmax_cross_entropy(
                logits=out,
                onehot_labels=self.Y)
                
            self.loss = self.cross_entropy_loss + self.l2_norm

            labels = tf.argmax(self.Y, axis=1)
            self.predictions = tf.argmax(out, axis=1)

            self.accuracy = tf.reduce_mean(
                tf.cast(tf.equal(labels, self.predictions), tf.float32))


            # replacing with more standard aproach
            self.global_step = tf.Variable(
                0, name='global_step', trainable=False, dtype=tf.int64)

            # support batch norm
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
            with tf.control_dependencies(update_ops):
                self.training = tf.train.AdamOptimizer().minimize(
                    self.loss, global_step=self.global_step, name="training")

            # adding summary writer for TensorBoard
            summary_writer = tf.contrib.summary.create_file_writer(
                self.logdir, flush_millis=10 * 1000)
            self.summaries = {}
            with summary_writer.as_default(), tf.contrib.summary.record_summaries_every_n_global_steps(10):
                self.summaries["train"] = [tf.contrib.summary.scalar("train/loss", self.loss),
                                           tf.contrib.summary.scalar("train/accuracy", self.accuracy)]

            with summary_writer.as_default(), tf.contrib.summary.always_record_summaries():
                self.summaries["val"] = [tf.contrib.summary.scalar("val/loss", self.loss),
                                         tf.contrib.summary.scalar("val/accuracy", self.accuracy)]

            # Initialize variables
            self.session.run(tf.global_variables_initializer())
            with summary_writer.as_default():
                tf.contrib.summary.initialize(
                    session=self.session, graph=self.session.graph)

    # Methods for running the tf evaluation

    def train_net(self, data, labels):
        return self.session.run(
            fetches=[self.training, self.summaries["train"],
                     self.loss, self.accuracy],
            feed_dict={self.X: data, self.Y: labels, self.is_training: True})

    def evaluate_net(self, summary_type, data, labels):
        return self.session.run(
            fetches=[self.loss, self.accuracy, self.summaries[summary_type]],
            feed_dict={self.X: data, self.Y: labels, self.is_training: False})

    def predict_net(self, data):
        return self.session.run(
            fetches=[self.predictions],
            feed_dict={self.X: data, self.is_training: False})[0]

    def train(self, train_data, train_labels, val_data, val_labels, epochs=20, batch_size=512, log_interval=50):
        """ Train the feed forward neural network.

        Parameters
        ----------
        train_data: np.array, shape [N, D]
            The training data. N corresponds to the number of training samples, D to the dimensionality of the data samples/
        train_labels: np.array, shape [N, K]
            The training labels

        val_data: np.array, shape [N, D]
            The validation data. dim same as train_data
        val_labels: np.array, shape [N, K]
            The validation labels

        epochs: int
            The number of epochs to train for.
        batch_size: int
            The batch size used for training.

        Returns
        -------
        None
        """

        for epoch in range(epochs):
            epoch_train_loss, epoch_train_acc = [], []
            for batch_ixs in batch_data(len(train_data), batch_size):
                X = train_data[batch_ixs]
                Y = train_labels[batch_ixs]
                _, _, train_loss, train_acc = self.train_net(X, Y)
                epoch_train_loss.append(train_loss)
                epoch_train_acc.append(train_acc)

            val_acc = 0.0
            do_validation = val_data is not None
            if do_validation:
                val_loss, val_acc, _ = self.evaluate_net(
                    "val", val_data, val_labels)
                train_loss = np.average(epoch_train_loss)
                train_acc = np.average(epoch_train_acc)

            if (epoch + 1) % log_interval == 0:
                train_acc_str = "%.1f" % (train_acc * 100)
                val_acc_str = "%.1f" % (val_acc * 100) if do_validation else "-"
                print("Epoch {}/{}:, v_ac:{}%, t_ac:{}%".format(
                    epoch+1,
                    epochs,
                    val_acc_str,
                    train_acc_str))

    def predict(self, data):
        """ Evaluate dataset using the network.
        Parameters
        ----------
        data: np.array, shape [N, D]
            The data to be labeled. N corresponds to the number of samples, D to the dimensionality of the data samples
        Returns
        -------
        labels: np.array, shape [N, K]
            The labels predicted for each data sample.
        """
        return self.predict_net(data)




def batch_data(num_data, batch_size):
    """ Yield batches with indices until epoch is over.

    Parameters
    ----------
    num_data: int
        The number of samples in the dataset.
    batch_size: int
        The batch size used using training.

    Returns
    -------
    batch_ixs: np.array of ints with shape [batch_size,]
        Yields arrays of indices of size of the batch size until the epoch is over.
    """
    batch_size = min(num_data, batch_size)

    data_ixs = np.random.permutation(np.arange(num_data))
    ix = 0
    while ix + batch_size <= num_data:
        batch_ixs = data_ixs[ix:ix+batch_size]
        ix += batch_size
        yield batch_ixs

def get_dataset():
    # dataset check and download
    if not os.path.isfile("homework_09_data.npz"):
        print("You are missing the dataset :(. Do you want me to download it for you? [y/n]")
        if raw_input().lower() in {'yes','y', 'ye', 'hellyea'}:
            print("Downloading it now... (4megs without a progress bar, be patient)")
            urllib.urlretrieve ("https://syncandshare.lrz.de/dl/fiXnRq4MRd8fGJBXH2jQmNcN/homework_09_data.npz", "homework_09_data.npz")
        else:
            exit()

    return np.load("homework_09_data.npz")