import numpy as np
from scipy.stats import mode
import glob

# this script takes care for ensambling multiple models to one by majority vote for every sample


files = glob.glob("./results/*.txt")
# do not ensamble final result file if it was created before
results = [np.genfromtxt(f, dtype=np.int32, delimiter='\n') for f in files if not f.endswith("final.txt")]
print("Number of files ensambled: {}".format(len(results)))
# use scipy method to get for which class we have the most votes
results = mode(results, axis=0)[0]
np.savetxt("./results/final.txt", results, fmt='%i', delimiter='\n')