###########################################################
# you can run the code with
# 
## python script.py
# 
# to train the model with validation
###########################################################
# or you can run it with
#
## python script.py --train-all && python ensamble.py
#
# to train the model on all available data and then produce the final annotation for the test_data
# you will find the result in ./results/final.txt
###########################################################

# this script is used for hyper-parameters tuning

import numpy as np
import tensorflow as tf
import datetime
import time
import sys
import os

import network
from network import FeedForwardNet


# disable the anoying tf logs
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

dataset = network.get_dataset()

train_data = dataset['train_data']
train_labels = dataset['train_labels']

val_data = dataset['val_data']
val_labels = dataset['val_labels']

test_data = dataset['test_data']

all_data = np.concatenate((train_data, val_data), axis=0)
all_labels = np.concatenate((train_labels, val_labels), axis=0)

train_all = False
if "--train-all" in sys.argv:
    train_all = True


###########################################################
# here you can specify hyper-parameters of the trained models
epochs = 500

hidden_sizess = [[512, 256, 128], [256, 128, 64]]
batch_sizes = [128, 256, 64]

# regularization
l2_strengths = [0]
dropouts = [0]
use_bns = [False]
###########################################################

for batch_size in batch_sizes:
    for hidden_sizes in hidden_sizess:
        for l2_strength in l2_strengths:
            for dropout in dropouts:
                for use_bn in use_bns:
                    print("-------------------------------")
                    param_str = "hid: {}, bs: {}, l2: {}, do: {}, bn: {}".format(
                        '-'.join(str(x) for x in hidden_sizes),
                        batch_size,
                        l2_strength,
                        dropout,
                        use_bn)

                    print(param_str)

                    logdir = "logs/{}-{}".format(
                        datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S"),
                        param_str)

                    start = time.time()

                    net = FeedForwardNet(
                        logdir, hidden_sizes, l2_strength, dropout, use_bn)

                    net.build(
                        train_data.shape[1],
                        num_classes=train_labels.shape[1])

                    if train_all:
                        net.train(
                            all_data, all_labels,
                            None, None,
                            epochs, batch_size=batch_size)
                    else:
                        net.train(
                            train_data, train_labels,
                            val_data, val_labels,
                            epochs, batch_size=batch_size)

                    test_predictions = net.predict(test_data)

                    if train_all:
                        file_name = "results/{}.txt".format(param_str)
                        if not os.path.exists("results/"):
                            os.makedirs("results/")
                        np.savetxt(
                            fname=file_name,
                            X=test_predictions,
                            fmt='%i',
                            delimiter='\n')

                    end = time.time()
                    print("%.1f" % ((end - start) / 60.0) + " minutes")